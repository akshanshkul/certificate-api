<?php

use CodeIgniter\Router\RouteCollection;
/**
 * @var RouteCollection $routes
 */
$routes->GET('/', 'Home::index');

$routes->POST('api/login', 'Api\Auth::login');

$routes->group('api', ['filter' => 'jwt'], function ($routes) {
    $routes->POST('registerUser', 'Api\Auth::registerUser');
    $routes->POST('logout', 'Api\Auth::logout');
    $routes->POST('clients/create', 'Api\Client::createClient');
    $routes->POST('clients/(:num)/keys', 'Api\Client::generateApiKey/$1');


});

$routes->group('api/certificate', ['filter' => 'apiAuth'], function ($routes) {
    $routes->POST('create', 'Api\Certificate::create');
    $routes->POST('template/upload', 'Api\Certificate::templateUpload');
    $routes->POST('template/update', 'Api\Certificate::templateUpdate');
    $routes->POST('template/upload/data', 'Api\Certificate::templateUploadData');
    $routes->POST('generate', 'Api\Certificate::generate');
    $routes->GET('download/all/(:num)', 'Api\Certificate::downloadAllCertificates/$1');
    $routes->GET('download/zip/(:num)', 'Api\Certificate::downloadAllCertificates/$1');

    $routes->POST('generate/send', 'Api\Certificate::generateSend');

    // 7. Delete generated certificate or last generated certificate
    $routes->POST('delete', 'Api\Certificate::delete');
    $routes->post('zip', 'Api\CertificateZipController::create');
    $routes->post(
        'zip/status',
        'Api\CertificateZipController::status'
    );
    $routes->post('zip/cancel', 'Api\CertificateZipController::cancel');



});
$routes->match(['GET', 'POST'], 'api/certificate/verify/(:num)', 'Api\Certificate::verify/$1');
$routes->post('api/cron/certificates/zip', 'Api\CronController::processCertificateZip');




// optional: explicit GET ~> method not allowed JSON (avoid 404 for accidental browser GET)
$routes->GET('(:any)', function ($segment) {
    http_response_code(405);
    header('Content-Type: application/json; charset=utf-8');
    return json_encode([
        'success' => 0,
        'status' => false,
        'message' => 'Method Not Allowed. Use POST for API endpoints.'
    ]);
});
