<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use CodeIgniter\API\ResponseTrait;
use App\Models\CertificateZipJobModel;
use App\Models\GeneratedCertificateModel;
use App\Libraries\S3Service;

class CronController extends BaseController
{
    use ResponseTrait;

    /**
     * POST /api/cron/certificates/zip
     */
 public function processCertificateZip()
{
    $token = $this->request->getHeaderLine('X-CRON-TOKEN');
    if ($token !== getenv('CRON_SECRET')) {
        return $this->failUnauthorized('Invalid cron token');
    }

    $jobModel = new CertificateZipJobModel();
    $generatedModel = new GeneratedCertificateModel();
    $s3 = new S3Service();

    $job = $jobModel->where('status', 'pending')->orderBy('id', 'ASC')->first();

    if (!$job) {
        return $this->respond([
            'success' => 1,
            'message' => 'No pending ZIP jobs'
        ]);
    }

    $jobId = $job['id'];
    $jobModel->markProcessing($jobId);

   $zip = new \ZipArchive();
$zipPath = null;
$zipOpened = false;

try {

    $zipPath = $tmpDir . "certificates_job_{$jobId}.zip";

    $openResult = $zip->open(
        $zipPath,
        \ZipArchive::CREATE | \ZipArchive::OVERWRITE
    );

    if ($openResult !== true) {
        throw new \RuntimeException("ZIP open failed ({$openResult})");
    }

    $zipOpened = true;

    foreach ($files as $i => $file) {

        if ($jobModel->isCancelled($jobId)) {
            // ❌ DO NOT CLOSE ZIP HERE
            return $this->respond(['status' => 'cancelled']);
        }

        $tmpPdf = $tmpDir . uniqid('pdf_', true) . '.pdf';
        $s3->downloadToLocal($file['file_path'], $tmpPdf);

        $zip->addFile($tmpPdf, basename($file['file_path']));
        unlink($tmpPdf);

        $jobModel->updateProgress($jobId, $i + 1);
    }

    // ✅ CLOSE ZIP IN EXACTLY ONE PLACE
    $zip->close();
    $zipOpened = false;

    if (!file_exists($zipPath)) {
        throw new \RuntimeException('ZIP file missing');
    }

    $s3->uploadLocalFile($zipPath, $zipKey, [
        'mimeType' => 'application/zip'
    ]);

    unlink($zipPath);
    $jobModel->markCompleted($jobId, $zipKey);

    return $this->respond([
        'success' => 1,
        'status' => 'completed'
    ]);

} catch (\Throwable $e) {

    // ❌ NEVER close ZIP here
    if ($zipPath && file_exists($zipPath)) {
        unlink($zipPath);
    }

    $jobModel->markFailed($jobId, $e->getMessage());
    return $this->failServerError($e->getMessage());
}
}

}
